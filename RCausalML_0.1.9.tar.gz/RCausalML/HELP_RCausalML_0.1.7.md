# RCausalML 0.1.7 Tarball Help

This guide explains how to install and use `RCausalML_0.1.7.tar.gz`.

## 1) Install From Tarball

From R:

```r
install.packages("RCausalML_0.1.7.tar.gz", repos = NULL, type = "source")
```

From shell:

```bash
R CMD INSTALL RCausalML_0.1.7.tar.gz
```

## 2) Dependency Setup Behavior

`RCausalML` version `0.1.7` includes an install-time `configure` hook.

- In an **interactive** install, it can prompt you to approve installing/updating dependencies.
- In a **non-interactive** install (CI, scripts, some IDE/background runs), it skips auto-install and prints the manual command to run.

## 3) Manual Dependency Install/Update (Recommended)

If dependencies are missing or old:

```r
install.packages(c(
  "glmnet", "ranger", "rpart", "R6", "expm", "igraph", "progress", "htetree",
  "xgboost", "torch", "grf", "DoubleML", "mlr3", "mlr3learners",
  "mlr3tuning", "paradox", "mlr3measures", "MatchIt", "reticulate",
  "kernelshap", "shapviz", "causaldata"
))
```

Core packages are in `Imports`; others are optional (`Suggests`) and needed for specific models/features.

## 4) Load Package

```r
library(RCausalML)
```

If installed to a project-local library (for example `.Rlibrary`), set library paths first:

```r
.libPaths(c("RCausalML/.Rlibrary", .libPaths()))
library(RCausalML)
```

## 5) Quick Smoke Test

```r
library(RCausalML)
set.seed(42)
d <- synthetic_data(mode = 1, n = 400, p = 5, sigma = 1)
m <- SLearner(learner = "ranger")
m <- fit(m, d$X, d$w, d$y)
ate <- estimate_ate(m, d$X, d$w, d$y)
print(ate)
```

## 6) Common Issues

- **Permission denied to default R library**
  - Install to a writable local library:
    ```bash
    mkdir -p .Rlibrary
    R CMD INSTALL -l .Rlibrary RCausalML_0.1.7.tar.gz
    ```

- **Repository/index access errors**
  - Check internet access and CRAN mirror:
    ```r
    options(repos = c(CRAN = "https://cloud.r-project.org"))
    ```
  - Then run `install.packages(...)` again.

- **Torch/CUDA warnings**
  - CPU execution is expected when CUDA is unavailable.
  - Most algorithms still run on CPU.

## 7) Where To Look Next

- Main package documentation: `README.md`
- Function help in R: `?SLearner`, `?DMLearner`, `?causalStructureML`
- Test scripts for examples: `tests/`
