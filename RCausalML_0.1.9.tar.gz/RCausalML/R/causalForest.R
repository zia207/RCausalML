# CausalForest.R
# A from-scratch implementation of Causal Forest (Wager & Athey, 2018)
# Estimates heterogeneous treatment effects via honest causal trees

# ============================================================
# UTILITIES
# ============================================================

#' Compute propensity scores via logistic regression or provided values
.estimate_propensity <- function(X, W) {
  fit <- glm(W ~ ., data = data.frame(W = W, X), family = binomial())
  predict(fit, type = "response")
}

#' Compute outcome residuals (Y - E[Y|X])
.estimate_outcome <- function(X, Y) {
  fit <- lm(Y ~ ., data = data.frame(Y = Y, X))
  residuals(fit)
}

#' Sample split: return indices for two non-overlapping halves
.honest_split <- function(n, fraction = 0.5) {
  idx <- sample(seq_len(n))
  split_at <- floor(n * fraction)
  list(
    train = idx[seq_len(split_at)],
    est   = idx[(split_at + 1):n]
  )
}

#' Compute sample weights (uniform if NULL)
.resolve_weights <- function(weights, n) {
  if (is.null(weights)) rep(1.0 / n, n) else weights / sum(weights)
}

#' Variance of a weighted vector
.weighted_var <- function(x, w) {
  mu <- sum(w * x) / sum(w)
  sum(w * (x - mu)^2) / sum(w)
}

# ============================================================
# CAUSAL TREE (single tree)
# ============================================================

#' Build one honest causal tree
#'
#' @param X          Covariate matrix (numeric)
#' @param Y_res      Outcome residuals (Y - Y.hat)
#' @param W_res      Treatment residuals (W - W.hat)
#' @param sample_wts Per-observation weights
#' @param train_idx  Indices used for splitting
#' @param est_idx    Indices used for leaf estimation
#' @param mtry       Features to consider at each split
#' @param min_node   Minimum leaf size
#' @param alpha      Regularization: min fraction of data in each child
#' @param imbalance_penalty Penalizes unbalanced splits
#' @return A list representing the tree (recursive node structure)
.build_causal_tree <- function(X, Y_res, W_res, sample_wts,
                                train_idx, est_idx,
                                mtry, min_node, alpha,
                                imbalance_penalty) {

  n_train <- length(train_idx)
  n_est   <- length(est_idx)

  # --- Leaf node: estimate tau via local Wald-style estimate ---
  .make_leaf <- function(est_idx) {
    w  <- sample_wts[est_idx]
    yr <- Y_res[est_idx]
    wr <- W_res[est_idx]
    denom <- sum(w * wr^2)
    tau   <- if (abs(denom) < 1e-10) 0 else sum(w * yr * wr) / denom
    var_tau <- if (length(est_idx) < 2) Inf else {
      eps <- yr - tau * wr
      sum(w^2 * eps^2) / (denom^2 + 1e-10)
    }
    list(
      is_leaf  = TRUE,
      tau      = tau,
      var_tau  = var_tau,
      n_est    = n_est,
      est_idx  = est_idx
    )
  }

  # Stop early?
  if (n_train < 2 * min_node || n_est < 2) {
    return(.make_leaf(est_idx))
  }

  # --- Select random feature subset ---
  p        <- ncol(X)
  features <- sample(seq_len(p), min(mtry, p))

  best_gain  <- -Inf
  best_feat  <- NULL
  best_thresh <- NULL

  # --- Score a candidate split ---
  .split_score <- function(left_tr, right_tr) {
    if (length(left_tr) < min_node || length(right_tr) < min_node) return(-Inf)

    # Fraction-based balance penalty
    f_left  <- length(left_tr) / n_train
    f_right <- length(right_tr) / n_train
    if (f_left < alpha || f_right < alpha) return(-Inf)

    score_side <- function(idx) {
      w  <- sample_wts[idx]
      wr <- W_res[idx]
      yr <- Y_res[idx]
      denom <- sum(w * wr^2)
      if (denom < 1e-10) return(0)
      (sum(w * yr * wr))^2 / denom
    }

    gain <- score_side(left_tr) + score_side(right_tr)

    # Imbalance penalty discourages very unequal splits
    if (imbalance_penalty > 0) {
      imbalance <- abs(f_left - f_right)
      gain <- gain - imbalance_penalty * imbalance
    }

    gain
  }

  # --- Search over features and thresholds ---
  for (feat in features) {
    vals    <- X[train_idx, feat]
    uniq    <- sort(unique(vals))
    if (length(uniq) < 2) next

    # Candidate thresholds: midpoints between sorted unique values
    thresholds <- (uniq[-length(uniq)] + uniq[-1]) / 2

    for (thresh in thresholds) {
      left_tr  <- train_idx[vals <= thresh]
      right_tr <- train_idx[vals >  thresh]
      gain     <- .split_score(left_tr, right_tr)

      if (gain > best_gain) {
        best_gain   <- gain
        best_feat   <- feat
        best_thresh <- thresh
      }
    }
  }

  # No valid split found
  if (is.null(best_feat)) return(.make_leaf(est_idx))

  # --- Partition estimation set by best split ---
  est_vals   <- X[est_idx, best_feat]
  left_est   <- est_idx[est_vals <= best_thresh]
  right_est  <- est_idx[est_vals >  best_thresh]

  train_vals  <- X[train_idx, best_feat]
  left_train  <- train_idx[train_vals <= best_thresh]
  right_train <- train_idx[train_vals >  best_thresh]

  if (length(left_est) == 0 || length(right_est) == 0) {
    return(.make_leaf(est_idx))
  }

  # --- Recurse ---
  list(
    is_leaf    = FALSE,
    feature    = best_feat,
    threshold  = best_thresh,
    left       = .build_causal_tree(X, Y_res, W_res, sample_wts,
                                     left_train, left_est,
                                     mtry, min_node, alpha,
                                     imbalance_penalty),
    right      = .build_causal_tree(X, Y_res, W_res, sample_wts,
                                     right_train, right_est,
                                     mtry, min_node, alpha,
                                     imbalance_penalty)
  )
}

#' Route a single observation through a tree, return leaf node
.predict_tree <- function(tree, x_row) {
  node <- tree
  while (!node$is_leaf) {
    if (x_row[node$feature] <= node$threshold) {
      node <- node$left
    } else {
      node <- node$right
    }
  }
  node
}

# ============================================================
# MAIN: causal_forest()
# ============================================================

#' Fit a Causal Forest
#'
#' @param X                    Numeric covariate matrix (n x p)
#' @param Y                    Numeric outcome vector (length n)
#' @param W                    Binary or continuous treatment vector (length n)
#' @param Y.hat                Pre-estimated E[Y|X]; estimated if NULL
#' @param W.hat                Pre-estimated E[W|X]; estimated if NULL
#' @param num.trees            Number of trees
#' @param sample.weights       Observation weights; uniform if NULL
#' @param clusters             Cluster IDs for cluster-robust sampling (optional)
#' @param equalize.cluster.weights  Balance sampling across clusters
#' @param sample.fraction      Fraction of data per tree
#' @param mtry                 Features tried per split
#' @param min.node.size        Minimum observations in a leaf
#' @param honesty              Use honest splitting
#' @param honesty.fraction     Fraction of subsample used for estimation
#' @param honesty.prune.leaves Remove leaves with no estimation samples
#' @param alpha                Minimum split fraction (regularization)
#' @param imbalance.penalty    Penalty on unbalanced splits
#' @param stabilize.splits     Use W residuals in split criterion
#' @param ci.group.size        Trees grouped for variance estimation
#' @param tune.parameters      "none" or "all"
#' @param compute.oob.predictions  Compute out-of-bag CATE predictions
#' @param num.threads          Parallel threads (uses parallel package if > 1)
#' @param seed                 Random seed for reproducibility
#' @return A causal_forest object
#' @seealso
#' \code{\link{RCausalML-package}}
#' @examples
#' \dontrun{
#' # Basic usage
#' # causal_forest(...)
#' }
#' @export
causal_forest <- function(X, Y, W,
                           Y.hat                     = NULL,
                           W.hat                     = NULL,
                           num.trees                 = 2000,
                           sample.weights            = NULL,
                           clusters                  = NULL,
                           equalize.cluster.weights  = FALSE,
                           sample.fraction           = 0.5,
                           mtry                      = min(ceiling(sqrt(ncol(X)) + 20), ncol(X)),
                           min.node.size             = 5,
                           honesty                   = TRUE,
                           honesty.fraction          = 0.5,
                           honesty.prune.leaves      = TRUE,
                           alpha                     = 0.05,
                           imbalance.penalty         = 0,
                           stabilize.splits          = TRUE,
                           ci.group.size             = 2,
                           tune.parameters           = "none",
                           compute.oob.predictions   = TRUE,
                           num.threads               = 1,
                           seed                      = NULL) {

  # --- Input validation ---
  X <- as.matrix(X)
  Y <- as.numeric(Y)
  W <- as.numeric(W)
  n <- nrow(X)
  p <- ncol(X)

  stopifnot(length(Y) == n, length(W) == n)
  stopifnot(sample.fraction > 0, sample.fraction <= 1)
  stopifnot(honesty.fraction > 0, honesty.fraction < 1)
  stopifnot(min.node.size >= 1)
  stopifnot(alpha >= 0, alpha < 0.5)

  if (!is.null(seed)) set.seed(seed)

  # --- Nuisance estimation (DR / Robinson decomposition) ---
  message("Estimating nuisance functions...")

  if (is.null(Y.hat)) {
    Y.hat <- fitted(lm(Y ~ ., data = data.frame(Y, X)))
  }
  if (is.null(W.hat)) {
    W.hat <- .estimate_propensity(X, W)
  }

  Y_res <- Y - Y.hat   # outcome residuals
  W_res <- W - W.hat   # treatment residuals

  # --- Sample weights ---
  sw <- .resolve_weights(sample.weights, n)

  # --- Optional: tune hyperparameters ---
  if (tune.parameters != "none") {
    message("Parameter tuning not fully implemented; using supplied parameters.")
  }

  # --- Cluster-aware subsampling helper ---
  .draw_subsample <- function() {
    sub_n <- max(1, floor(n * sample.fraction))

    if (!is.null(clusters)) {
      cl_ids   <- unique(clusters)
      if (equalize.cluster.weights) {
        chosen_cl <- sample(cl_ids, size = ceiling(length(cl_ids) * sample.fraction),
                            replace = FALSE)
      } else {
        chosen_cl <- sample(cl_ids, size = ceiling(length(cl_ids) * sample.fraction),
                            replace = FALSE)
      }
      idx <- which(clusters %in% chosen_cl)
    } else {
      idx <- sample(seq_len(n), size = sub_n, replace = FALSE)
    }

    if (honesty) {
      split    <- .honest_split(length(idx), honesty.fraction)
      train_idx <- idx[split$train]
      est_idx   <- idx[split$est]
    } else {
      train_idx <- idx
      est_idx   <- idx
    }

    list(train = train_idx, est = est_idx, all = idx)
  }

  # --- Grow forest ---
  message(sprintf("Growing %d causal trees...", num.trees))

  grow_one_tree <- function(b) {
    samp      <- .draw_subsample()
    tree      <- .build_causal_tree(
      X             = X,
      Y_res         = Y_res,
      W_res         = W_res,
      sample_wts    = sw,
      train_idx     = samp$train,
      est_idx       = samp$est,
      mtry          = mtry,
      min_node      = min.node.size,
      alpha         = alpha,
      imbalance_penalty = imbalance.penalty
    )
    list(tree = tree, oob_idx = setdiff(seq_len(n), samp$all))
  }

  if (num.threads > 1 && requireNamespace("parallel", quietly = TRUE)) {
    cl_par <- parallel::makeCluster(num.threads)
    on.exit(parallel::stopCluster(cl_par), add = TRUE)
    parallel::clusterExport(cl_par,
      c(".build_causal_tree", ".honest_split", ".resolve_weights",
        ".weighted_var", ".draw_subsample",
        "X", "Y_res", "W_res", "sw", "n",
        "sample.fraction", "honesty", "honesty.fraction",
        "mtry", "min.node.size", "alpha", "imbalance.penalty",
        "clusters", "equalize.cluster.weights"),
      envir = environment())
    trees_list <- parallel::parLapply(cl_par, seq_len(num.trees), grow_one_tree)
  } else {
    trees_list <- lapply(seq_len(num.trees), grow_one_tree)
  }

  trees    <- lapply(trees_list, `[[`, "tree")
  oob_sets <- lapply(trees_list, `[[`, "oob_idx")

  # --- OOB predictions ---
  oob_predictions <- rep(NA_real_, n)
  oob_counts      <- rep(0L, n)

  if (compute.oob.predictions) {
    message("Computing OOB predictions...")
    for (i in seq_along(trees)) {
      oob_i <- oob_sets[[i]]
      if (length(oob_i) == 0) next
      for (j in oob_i) {
        leaf <- .predict_tree(trees[[i]], X[j, ])
        if (!is.null(leaf$tau) && is.finite(leaf$tau)) {
          oob_predictions[j] <- sum(c(oob_predictions[j], leaf$tau), na.rm = TRUE)
          oob_counts[j]      <- oob_counts[j] + 1L
        }
      }
    }
    nonzero <- oob_counts > 0
    oob_predictions[nonzero] <- oob_predictions[nonzero] / oob_counts[nonzero]
  }

  # --- Return forest object ---
  structure(
    list(
      trees              = trees,
      oob_sets           = oob_sets,
      oob_predictions    = oob_predictions,
      X                  = X,
      Y                  = Y,
      W                  = W,
      Y.hat              = Y.hat,
      W.hat              = W.hat,
      Y_res              = Y_res,
      W_res              = W_res,
      sample_weights     = sw,
      num.trees          = num.trees,
      mtry               = mtry,
      min.node.size      = min.node.size,
      honesty            = honesty,
      honesty.fraction   = honesty.fraction,
      alpha              = alpha,
      imbalance.penalty  = imbalance.penalty,
      ci.group.size      = ci.group.size,
      n                  = n,
      p                  = p
    ),
    class = "causal_forest"
  )
}

# ============================================================
# PREDICT: predict.causal_forest()
# ============================================================

#' Predict treatment effects from a causal forest
#'
#' @param object       A causal_forest object
#' @param newdata      New covariate matrix; uses training data if NULL
#' @param estimate.variance  Return variance estimates alongside predictions
#' @param num.threads  Threads for parallel prediction
#' @param ...          Ignored
#' @return A list with `predictions` and optionally `variance.estimates`
#' @seealso
#' \code{\link{RCausalML-package}}
#' @examples
#' \dontrun{
#' # Basic usage
#' # predict.causal_forest(...)
#' }
#' @export
predict.causal_forest <- function(object, newdata = NULL,
                                   estimate.variance = FALSE,
                                   num.threads = 1,
                                   ...) {

  if (is.null(newdata)) {
    # Return OOB predictions for training data
    if (estimate.variance) {
      message("Variance estimates use grouped-tree IJ method on OOB predictions.")
    }
    return(list(
      predictions        = object$oob_predictions,
      variance.estimates = if (estimate.variance)
        .compute_oob_variance(object) else NULL
    ))
  }

  X_new <- as.matrix(newdata)
  stopifnot(ncol(X_new) == object$p)
  m     <- nrow(X_new)
  trees <- object$trees
  B     <- length(trees)

  # --- Predict each new obs across all trees ---
  pred_matrix <- matrix(NA_real_, nrow = m, ncol = B)

  predict_one <- function(b) {
    sapply(seq_len(m), function(i) {
      leaf <- .predict_tree(trees[[b]], X_new[i, ])
      leaf$tau
    })
  }

  if (num.threads > 1 && requireNamespace("parallel", quietly = TRUE)) {
    cl_par <- parallel::makeCluster(num.threads)
    on.exit(parallel::stopCluster(cl_par), add = TRUE)
    parallel::clusterExport(cl_par,
      c(".predict_tree", "trees", "X_new", "m"),
      envir = environment())
    results <- parallel::parLapply(cl_par, seq_len(B), predict_one)
  } else {
    results <- lapply(seq_len(B), predict_one)
  }

  for (b in seq_len(B)) pred_matrix[, b] <- results[[b]]

  predictions <- rowMeans(pred_matrix, na.rm = TRUE)

  # --- Variance via grouped infinitesimal jackknife (IJ) ---
  var_estimates <- NULL
  if (estimate.variance) {
    var_estimates <- .compute_variance_ij(pred_matrix, object$ci.group.size)
  }

  list(
    predictions        = predictions,
    variance.estimates = var_estimates
  )
}

# ============================================================
# VARIANCE ESTIMATION (grouped IJ)
# ============================================================

#' Variance estimation for new-data predictions via grouped IJ
.compute_variance_ij <- function(pred_matrix, ci.group.size) {
  m <- nrow(pred_matrix)
  B <- ncol(pred_matrix)

  # Group trees into blocks for IJ variance estimate
  n_groups <- floor(B / ci.group.size)
  if (n_groups < 2) {
    warning("Too few trees for grouped variance estimation. Increase num.trees.")
    return(rep(NA_real_, m))
  }

  group_means <- matrix(NA_real_, nrow = m, ncol = n_groups)
  for (g in seq_len(n_groups)) {
    cols <- ((g - 1) * ci.group.size + 1):(g * ci.group.size)
    group_means[, g] <- rowMeans(pred_matrix[, cols, drop = FALSE], na.rm = TRUE)
  }

  # Variance across group means, scaled by number of groups
  apply(group_means, 1, var, na.rm = TRUE) / n_groups
}

#' OOB variance estimate (used when newdata = NULL)
.compute_oob_variance <- function(object) {
  n     <- object$n
  trees <- object$trees
  oob   <- object$oob_sets
  B     <- length(trees)
  ci_g  <- object$ci.group.size
  X     <- object$X

  oob_mat <- matrix(NA_real_, nrow = n, ncol = B)
  for (b in seq_len(B)) {
    for (j in oob[[b]]) {
      leaf <- .predict_tree(trees[[b]], X[j, ])
      oob_mat[j, b] <- leaf$tau
    }
  }
  .compute_variance_ij(oob_mat, ci_g)
}

# ============================================================
# SUMMARY / PRINT
# ============================================================

#' Print method for causal_forest
#' @return
#' Object returned by \code{print.causal_forest}.
#' @seealso
#' \code{\link{RCausalML-package}}
#' @examples
#' \dontrun{
#' # Basic usage
#' # print.causal_forest(...)
#' }
#' @export
print.causal_forest <- function(x, ...) {
  cat("Causal Forest\n")
  cat("-------------\n")
  cat(sprintf("  Trees         : %d\n", x$num.trees))
  cat(sprintf("  Observations  : %d\n", x$n))
  cat(sprintf("  Covariates    : %d\n", x$p))
  cat(sprintf("  Honesty       : %s (fraction = %.2f)\n",
              x$honesty, x$honesty.fraction))
  cat(sprintf("  min.node.size : %d\n", x$min.node.size))
  cat(sprintf("  mtry          : %d\n", x$mtry))
  cat(sprintf("  alpha         : %.3f\n", x$alpha))

  oob_valid <- sum(!is.na(x$oob_predictions))
  cat(sprintf("  OOB preds     : %d / %d obs covered\n", oob_valid, x$n))

  if (oob_valid > 0) {
    cat(sprintf("  ATE (OOB est) : %.4f\n", mean(x$oob_predictions, na.rm = TRUE)))
  }
  invisible(x)
}

#' Summary method for causal_forest
#' @return
#' Object returned by \code{summary.causal_forest}.
#' @seealso
#' \code{\link{RCausalML-package}}
#' @examples
#' \dontrun{
#' # Basic usage
#' # summary.causal_forest(...)
#' }
#' @export
summary.causal_forest <- function(object, ...) {
  cat("=== Causal Forest Summary ===\n\n")
  print(object)

  if (any(!is.na(object$oob_predictions))) {
    cat("\nOOB Prediction Distribution:\n")
    print(summary(object$oob_predictions))
  }
  invisible(object)
}

# ============================================================
# AVERAGE TREATMENT EFFECT
# ============================================================

#' Estimate Average Treatment Effect from a causal forest
#'
#' Uses augmented IPW (AIPW) / doubly robust estimator
#'
#' @param forest  A causal_forest object
#' @param subset  Optional integer index for subgroup ATE
#' @return A list with estimate, std.err, t-stat, p-value, confidence interval
#' @seealso
#' \code{\link{RCausalML-package}}
#' @examples
#' \dontrun{
#' # Basic usage
#' # average_treatment_effect(...)
#' }
#' @export
average_treatment_effect <- function(forest, subset = NULL) {
  n      <- forest$n
  idx    <- if (is.null(subset)) seq_len(n) else subset
  tau_hat <- forest$oob_predictions[idx]
  Y_res  <- forest$Y_res[idx]
  W_res  <- forest$W_res[idx]

  # Doubly-robust AIPW score
  dr_scores <- tau_hat + (W_res * (Y_res - tau_hat * W_res)) /
                 pmax(forest$W.hat[idx] * (1 - forest$W.hat[idx]), 1e-6)

  ate     <- mean(dr_scores, na.rm = TRUE)
  se      <- sd(dr_scores, na.rm = TRUE) / sqrt(sum(!is.na(dr_scores)))
  t_stat  <- ate / se
  p_val   <- 2 * pnorm(-abs(t_stat))
  ci      <- ate + c(-1, 1) * 1.96 * se

  list(
    estimate   = ate,
    std.err    = se,
    t.stat     = t_stat,
    p.value    = p_val,
    conf.int   = ci
  )
}

# ============================================================
# VARIABLE IMPORTANCE
# ============================================================

#' Variable importance from split frequency
#'
#' @param forest  A causal_forest object
#' @return Named numeric vector of importance scores (sums to 1)
#' @seealso
#' \code{\link{RCausalML-package}}
#' @examples
#' \dontrun{
#' # Basic usage
#' # variable_importance(...)
#' }
#' @export
variable_importance <- function(forest) {
  counts <- integer(forest$p)

  .count_splits <- function(node) {
    if (node$is_leaf) return(invisible(NULL))
    counts[node$feature] <<- counts[node$feature] + 1L
    .count_splits(node$left)
    .count_splits(node$right)
  }

  for (tree in forest$trees) .count_splits(tree)

  total <- sum(counts)
  if (total == 0) return(setNames(rep(0, forest$p), colnames(forest$X)))

  importance <- counts / total
  col_names  <- if (!is.null(colnames(forest$X))) colnames(forest$X) else
                  paste0("X", seq_len(forest$p))
  setNames(importance, col_names)
}
