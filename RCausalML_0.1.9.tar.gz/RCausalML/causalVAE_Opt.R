# ==============================================================================
#  causalVAE.R  — OPTIMISED
#
#  Changes vs original:
#   1. hidden_dim default 256 → 64   (~16× fewer FLOPS per linear layer)
#   2. Encoder/decoder: 3 fc layers → 2  (dropped enc_fc3 / dec_fc3)
#   3. Replaced DataLoader + coro::loop with:
#        train_epoch()      — pure tensor-index mini-batch loop
#        eval_pass()        — single/chunked forward pass, no loop overhead
#        fit_causal_vae()   — unified loop with early stopping + state restore
#        train_epoch_ate()  — ATE variant (x, T, Y batching)
#   4. Batch size default 256 (fewer R iterations per epoch vs 128)
#   5. dag_penalty() left unchanged — matrix_exp is fast for small latent_dim
# ==============================================================================
library(torch)

device <- torch_device(if (cuda_is_available()) "cuda" else "cpu")
cat(sprintf("Using device: %s\n", device$type))


# ==============================================================================
# DATA GENERATION  (unchanged)
# ==============================================================================
generate_data <- function(n_samples = 10000L, latent_dim = 3L) {
  epsilon_mat    <- matrix(rnorm(n_samples * latent_dim), nrow = n_samples)
  z_mat          <- matrix(0.0, nrow = n_samples, ncol = latent_dim)
  z_mat[, 1]     <- epsilon_mat[, 1]
  z_mat[, 2]     <- z_mat[, 1] + epsilon_mat[, 2]
  z_mat[, 3]     <- z_mat[, 2]^2 + epsilon_mat[, 3]
  x_mat          <- matrix(0.0, nrow = n_samples, ncol = latent_dim)
  x_mat[, 1]     <- z_mat[, 1] * z_mat[, 3]
  x_mat[, 2]     <- sin(z_mat[, 2]) + z_mat[, 1]
  x_mat[, 3]     <- z_mat[, 3]^2 + rnorm(n_samples, 0, 0.1)
  list(x       = torch_tensor(x_mat,       dtype = torch_float()),
       z       = torch_tensor(z_mat,       dtype = torch_float()),
       epsilon = torch_tensor(epsilon_mat, dtype = torch_float()))
}


# ==============================================================================
# CausalVAE  — 2-layer encoder/decoder · hidden_dim = 64 default
# ==============================================================================
CausalVAE <- nn_module(
  classname = "CausalVAE",
  
  initialize = function(
    input_dim       = 3L,
    latent_dim      = 3L,
    hidden_dim      = 64L,      # ← was 256; 4× smaller → ~16× fewer FLOPS
    beta            = 2.0,
    gamma           = 2.0,
    lambda_sparsity = 0.2,
    alpha           = 0.05
  ) {
    self$beta            <- beta
    self$gamma           <- gamma
    self$lambda_sparsity <- lambda_sparsity
    self$alpha           <- alpha
    self$latent_dim      <- as.integer(latent_dim)
    
    # Encoder: 2 hidden layers (was 3)
    self$enc_fc1    <- nn_linear(input_dim,  hidden_dim)
    self$enc_fc2    <- nn_linear(hidden_dim, hidden_dim)
    self$enc_mu_h   <- nn_linear(hidden_dim, latent_dim)
    self$enc_logv_h <- nn_linear(hidden_dim, latent_dim)
    
    # Decoder: 2 hidden layers (was 3)
    self$dec_fc1    <- nn_linear(latent_dim, hidden_dim)
    self$dec_fc2    <- nn_linear(hidden_dim, hidden_dim)
    self$dec_mu_h   <- nn_linear(hidden_dim, input_dim)
    self$dec_logv_h <- nn_linear(hidden_dim, input_dim)
    
    # Causal graph parameters
    self$a_weights <- nn_parameter(torch_randn(latent_dim, latent_dim) * 0.01)
    self$m_logits  <- nn_parameter(torch_randn(latent_dim, latent_dim) * 0.01)
  },
  
  encode = function(x) {
    h <- torch_relu(self$enc_fc2(torch_relu(self$enc_fc1(x))))
    list(mu = self$enc_mu_h(h), logvar = self$enc_logv_h(h))
  },
  
  reparameterize = function(mu, logvar) {
    mu + torch_exp(0.5 * logvar) * torch_randn_like(mu)
  },
  
  causal_layer = function(epsilon) {
    AM <- torch_tanh(self$a_weights) * torch_sigmoid(self$m_logits)
    I  <- torch_eye(self$latent_dim, device = epsilon$device, dtype = epsilon$dtype)
    tryCatch(
      torch_linalg_solve(I - AM$t(), epsilon$t())$t(),
      error = function(e) epsilon + torch_matmul(epsilon, AM)   # Neumann fallback
    )
  },
  
  # Unchanged — matrix_exp for a 3×5 matrix is already fast
  dag_penalty = function() {
    M   <- torch_sigmoid(self$m_logits)
    eye <- torch_eye(self$latent_dim, device = M$device, dtype = M$dtype)
    torch_trace(torch_matrix_exp(eye + self$alpha * M * M)) - self$latent_dim
  },
  
  decode = function(z) {
    h <- torch_relu(self$dec_fc2(torch_relu(self$dec_fc1(z))))
    list(mu = self$dec_mu_h(h), logvar = self$dec_logv_h(h))
  },
  
  # forward() return names unchanged — external API identical to original
  forward = function(x) {
    enc <- self$encode(x)
    eps <- self$reparameterize(enc$mu, enc$logvar)
    z   <- self$causal_layer(eps)
    dec <- self$decode(z)
    list(enc_mu     = enc$mu,     enc_logvar = enc$logvar,
         dec_mu     = dec$mu,     dec_logvar = dec$logvar,
         z = z, epsilon = eps)
  }
)


# ==============================================================================
# CausalVAE_ATE  (inherits CausalVAE, outcome head renamed → outcome_head)
# ==============================================================================
CausalVAE_ATE <- nn_module(
  classname = "CausalVAE_ATE",
  inherit   = CausalVAE,
  
  initialize = function(...) {
    super$initialize(...)
    self$outcome_head <- nn_linear(self$latent_dim + 1L, 1L)
  },
  
  # out$y_pred is still the key used in training code — unchanged
  forward = function(x, T = NULL) {
    out <- super$forward(x)
    if (!is.null(T))
      out$y_pred <- self$outcome_head(torch_cat(list(out$z, T), dim = 2L))
    out
  }
)


# ==============================================================================
# estimate_ate()
# ==============================================================================
estimate_ate <- function(model, n_samples = 1000L, treatment_dim = 1L,
                         shift = 1.0, device = torch_device("cpu")) {
  model$eval()
  with_no_grad({
    eps   <- torch_randn(n_samples, model$latent_dim)$to(device = device)
    z     <- model$causal_layer(eps)
    T0    <- torch_zeros(n_samples, 1L)$to(device = device)
    T1    <- torch_ones (n_samples, 1L)$to(device = device)
    y_t0  <- model$outcome_head(torch_cat(list(z,           T0), dim = 2L))$mean()
    delta <- torch_zeros_like(z)
    delta[, treatment_dim] <- shift
    y_t1  <- model$outcome_head(torch_cat(list(z + delta,   T1), dim = 2L))$mean()
    (y_t1 - y_t0)$item()
  })
}


# ==============================================================================
# loss_function()  (unchanged)
# ==============================================================================
loss_function <- function(x, dec_mu, dec_logvar, enc_mu, enc_logvar, model,
                          gamma_scale = 1.0) {
  dec_std <- torch_exp(0.5 * dec_logvar)$clamp(min = 1e-4)
  recon   <- (-0.5 * ((x - dec_mu) / dec_std)^2
              - torch_log(dec_std)
              - 0.5 * log(2 * pi))$sum(dim = -1L)$mean()
  
  enc_std <- torch_exp(0.5 * enc_logvar)$clamp(min = 1e-4)
  kl      <- (0.5 * (enc_std^2 + enc_mu^2 - 1.0 - 2.0 * torch_log(enc_std)))$mean()
  
  dag     <- model$dag_penalty()
  sparse  <- torch_sum(torch_abs(torch_sigmoid(model$m_logits)))
  causal  <- gamma_scale * model$gamma * (dag + model$lambda_sparsity * sparse)
  
  -recon + model$beta * kl + causal
}


# ==============================================================================
# FAST TRAINING HELPERS  — eliminate DataLoader / coro::loop R overhead
# ==============================================================================

#' One mini-batch epoch via plain R index shuffling (no DataLoader).
#' @return Average loss over all batches.
train_epoch <- function(model, x_tensor, optimizer,
                        batch_size = 256L, gamma_scale = 1.0,
                        device = torch_device("cpu")) {
  model$train()
  n     <- x_tensor$size(1L)
  perm  <- sample.int(n)            # 1-based R shuffle, zero overhead
  total <- 0.0;  nb <- 0L;  start <- 1L
  
  while (start <= n) {
    end   <- min(start + batch_size - 1L, n)
    x_b   <- x_tensor[perm[start:end], ]$to(device = device)
    
    optimizer$zero_grad()
    out  <- model$forward(x_b)
    loss <- loss_function(x_b, out$dec_mu, out$dec_logvar,
                          out$enc_mu, out$enc_logvar, model, gamma_scale)
    loss$backward()
    nn_utils_clip_grad_norm_(model$parameters, max_norm = 1.0)
    optimizer$step()
    
    total <- total + loss$item();  nb <- nb + 1L;  start <- end + 1L
  }
  total / nb
}


#' Validation in one (or chunked) forward pass — no loop per batch.
#' Chunks only when val set exceeds chunk_size (default 4096).
eval_pass <- function(model, x_val, gamma_scale = 1.0,
                      device = torch_device("cpu"), chunk_size = 4096L) {
  model$eval()
  n     <- x_val$size(1L)
  total <- 0.0;  nb <- 0L;  start <- 1L
  
  while (start <= n) {
    end   <- min(start + chunk_size - 1L, n)
    chunk_loss <- with_no_grad({
      x_b <- x_val[start:end, ]$to(device = device)
      out <- model$forward(x_b)
      loss_function(x_b, out$dec_mu, out$dec_logvar,
                    out$enc_mu, out$enc_logvar, model, gamma_scale)$item()
    })
    total <- total + chunk_loss;  nb <- nb + 1L;  start <- end + 1L
  }
  total / nb
}


#' Full training loop with warmup, early stopping, and best-model restore.
#' Replaces all manual for/coro loops in every training section.
#' @return list(train_losses, val_losses, best_epoch)
fit_causal_vae <- function(
    model, x_train, x_val, optimizer, scheduler,
    epochs        = 300L,
    warmup_epochs = 60L,
    batch_size    = 256L,
    patience      = 50L,
    device        = torch_device("cpu"),
    print_every   = 50L
) {
  tr_l <- numeric(epochs);  va_l <- numeric(epochs)
  best_val <- Inf;  best_ep <- 0L;  pat <- 0L;  last_ep <- 0L
  best_state <- NULL
  
  for (ep in seq_len(epochs)) {
    last_ep    <- ep
    gs         <- min(1.0, ep / warmup_epochs)
    tr_l[ep]   <- train_epoch(model, x_train, optimizer, batch_size, gs, device)
    va_l[ep]   <- eval_pass (model, x_val,               gs, device)
    scheduler$step(va_l[ep])
    
    if (va_l[ep] < best_val - 1e-5) {
      best_val   <- va_l[ep];  best_ep <- ep;  pat <- 0L
      best_state <- lapply(model$state_dict(),
                           function(t) t$clone()$detach())
    } else {
      pat <- pat + 1L
      if (pat >= patience) {
        cat(sprintf("  Early stop at epoch %d (best %d | val %.4f)\n",
                    ep, best_ep, best_val))
        break
      }
    }
    if (print_every > 0L && ep %% print_every == 0L)
      cat(sprintf("Epoch %4d | Train %.4f | Val %.4f | LR %.2e\n",
                  ep, tr_l[ep], va_l[ep], optimizer$param_groups[[1]]$lr))
  }
  
  if (!is.null(best_state)) model$load_state_dict(best_state)
  run <- seq_len(last_ep)
  list(train_losses = tr_l[run], val_losses = va_l[run], best_epoch = best_ep)
}


#' ATE-specific epoch: forward(x, T) + VAE loss + MSE on outcome head.
train_epoch_ate <- function(model_ate, x_tensor, T_tensor, Y_tensor, optimizer,
                            batch_size = 256L, gamma_scale = 1.0,
                            device = torch_device("cpu")) {
  model_ate$train()
  n    <- x_tensor$size(1L)
  perm <- sample.int(n)
  total <- 0.0;  nb <- 0L;  start <- 1L
  
  while (start <= n) {
    end  <- min(start + batch_size - 1L, n)
    idx  <- perm[start:end]
    x_b  <- x_tensor[idx, ]$to(device = device)
    t_b  <- T_tensor[idx, ]$to(device = device)
    y_b  <- Y_tensor[idx, ]$to(device = device)
    
    optimizer$zero_grad()
    out  <- model_ate$forward(x_b, t_b)
    loss <- loss_function(x_b, out$dec_mu, out$dec_logvar,
                          out$enc_mu, out$enc_logvar, model_ate, gamma_scale) +
      nnf_mse_loss(out$y_pred, y_b)
    loss$backward()
    nn_utils_clip_grad_norm_(model_ate$parameters, max_norm = 1.0)
    optimizer$step()
    
    total <- total + loss$item();  nb <- nb + 1L;  start <- end + 1L
  }
  total / nb
}


# ==============================================================================
# MODEL / OPTIMIZER SETUP (optional demo; do not run at package load)
# ==============================================================================
# Run only when needed, e.g. .causalvae_opt_demo_setup()
.causalvae_opt_demo_setup <- function() {
  model     <- CausalVAE()$to(device = device)
  optimizer <- optim_adam(model$parameters, lr = 5e-4, weight_decay = 1e-5)
  scheduler <- lr_reduce_on_plateau(optimizer, mode = "min", factor = 0.5, patience = 40L)
  n_params  <- sum(vapply(model$parameters, function(p) as.numeric(p$numel()), numeric(1L)))
  cat(sprintf("Parameters : %s\n", format(n_params, big.mark = ",")))
  invisible(list(model = model, optimizer = optimizer, scheduler = scheduler))
}
