# ==============================================================================
#  causal_iVAE.R
#  Identifiable Variational Autoencoders (iVAEs) — R/torch implementation
# ==============================================================================

library(torch)

# ---------------------------------------------------------------------------
# Device selection
# ---------------------------------------------------------------------------
device <- if (cuda_is_available()) torch_device("cuda") else torch_device("cpu")
cat(sprintf("Using device: %s\n", device$type))


# ==============================================================================
# iVAE Model
# ==============================================================================

iVAE <- nn_module(
  classname = "iVAE",
  
  # ---------------------------------------------------------------------------
  initialize = function(input_dim  = 2,
                        latent_dim = 2,
                        hidden_dim = 128,
                        n_aux      = 5,
                        dropout    = 0.15) {
    
    # ===== Encoder: q(z | x, u) =====
    # Concatenates x with one-hot(u); two hidden layers → (mu, logvar) for q(z|x,u)
    self$enc_fc1    <- nn_linear(input_dim + n_aux, hidden_dim)  # input → hidden
    self$enc_fc2    <- nn_linear(hidden_dim, hidden_dim)         # hidden → hidden
    self$enc_mu     <- nn_linear(hidden_dim, latent_dim)         # → posterior mean
    self$enc_logvar <- nn_linear(hidden_dim, latent_dim)         # → posterior log-variance
    
    # ===== Decoder: p(x | z) =====
    # Maps z through two hidden layers → (mu, logvar) for p(x|z)
    self$dec_fc1    <- nn_linear(latent_dim, hidden_dim)         # latent → hidden
    self$dec_fc2    <- nn_linear(hidden_dim, hidden_dim)         # hidden → hidden
    self$dec_mu     <- nn_linear(hidden_dim, input_dim)          # → reconstruction mean
    self$dec_logvar <- nn_linear(hidden_dim, input_dim)          # → reconstruction log-variance
    
    # ===== Conditional Prior: p(z | u) = N(lambda(u), I) =====
    # Linear map from one-hot(u) to prior mean; variance fixed at 1 (logvar = 0)
    self$prior_fc <- nn_linear(n_aux, latent_dim)
    
    # ===== Misc =====
    self$n_aux   <- n_aux
    self$dropout <- nn_dropout(p = dropout)
  },
  
  # ---------------------------------------------------------------------------
  encode = function(x, u) {
    # x : [B, input_dim]
    # u : 1-D *0-indexed* long tensor or integer vector  [B]
    #     (0-indexed to match Python/ML convention; +1L converts to R's 1-based indexing)
    u_onehot <- torch_eye(self$n_aux)$to(device = x$device)[u + 1L, ]  # [B, n_aux]
    inp  <- torch_cat(list(x, u_onehot), dim = 2)                       # [B, input_dim + n_aux]
    h    <- self$dropout(nnf_relu(self$enc_fc1(inp)))
    h    <- self$dropout(nnf_relu(self$enc_fc2(h)))
    list(
      mu     = self$enc_mu(h),      # [B, latent_dim]
      logvar = self$enc_logvar(h)   # [B, latent_dim]
    )
  },
  
  # ---------------------------------------------------------------------------
  reparameterize = function(mu, logvar) {
    # Reparameterization trick: z = mu + eps * std,  eps ~ N(0, I)
    # Enables gradient flow through the stochastic sampling step.
    std <- torch_exp(0.5 * logvar)   # std = sqrt(var)
    eps <- torch_randn_like(std)     # random noise
    mu + eps * std                   # sampled latent z  [B, latent_dim]
  },
  
  # ---------------------------------------------------------------------------
  decode = function(z) {
    # z : [B, latent_dim]
    # Returns list(mu, logvar) for p(x|z), both [B, input_dim]
    h <- self$dropout(nnf_relu(self$dec_fc1(z)))
    h <- self$dropout(nnf_relu(self$dec_fc2(h)))
    list(
      mu     = self$dec_mu(h),
      logvar = self$dec_logvar(h)
    )
  },
  
  # ---------------------------------------------------------------------------
  prior = function(u) {
    # Conditional prior p(z|u) = N(lambda(u), I)
    # logvar = 0  <=>  variance = 1  (fixed isotropic Gaussian)
    u_onehot     <- torch_eye(self$n_aux)$to(device = u$device)[u + 1L, ]
    prior_mu     <- self$prior_fc(u_onehot)       # [B, latent_dim]
    prior_logvar <- torch_zeros_like(prior_mu)    # [B, latent_dim], all zeros
    list(mu = prior_mu, logvar = prior_logvar)
  },
  
  # ---------------------------------------------------------------------------
  forward = function(x, u) {
    # Full forward pass — returns all quantities needed for the ELBO loss.
    enc <- self$encode(x, u)
    z   <- self$reparameterize(enc$mu, enc$logvar)
    dec <- self$decode(z)
    pri <- self$prior(u)
    
    list(
      enc_mu       = enc$mu,
      enc_logvar   = enc$logvar,
      dec_mu       = dec$mu,
      dec_logvar   = dec$logvar,
      prior_mu     = pri$mu,
      prior_logvar = pri$logvar
    )
  }
)


# ==============================================================================
# ELBO Loss Function
# ==============================================================================

#' Negative Evidence Lower Bound (ELBO) Loss for the iVAE
#'
#' @param x            Observed data batch             [B, input_dim]
#' @param dec_mu       Decoder mean                    [B, input_dim]
#' @param dec_logvar   Decoder log-variance            [B, input_dim]
#' @param enc_mu       Posterior mean    q(z|x,u)      [B, latent_dim]
#' @param enc_logvar   Posterior log-var q(z|x,u)      [B, latent_dim]
#' @param prior_mu     Prior mean        p(z|u)        [B, latent_dim]
#' @param prior_logvar Prior log-var     p(z|u)        [B, latent_dim]
#'
#' @return Scalar tensor — negative ELBO.  Lower is better.
elbo_loss <- function(x,
                      dec_mu, dec_logvar,
                      enc_mu, enc_logvar,
                      prior_mu, prior_logvar) {
  
  # --- Reconstruction: E_q[ log p(x | z) ] ---
  # p(x|z) = N(dec_mu, exp(dec_logvar))
  # Note: dec_logvar is log(sigma^2), so std = sqrt(exp(logvar)) = exp(0.5 * logvar)
  dec_std    <- torch_exp(dec_logvar)$sqrt()    # [B, input_dim]
  recon_dist <- distr_normal(dec_mu, dec_std)
  recon_loss <- recon_dist$log_prob(x)$sum(dim = -1)$mean()   # scalar
  
  # --- KL: KL( q(z|x,u) || p(z|u) ) — analytical Gaussian KL ---
  #
  # KL( N(mu1, s1^2) || N(mu2, s2^2) )
  #   = 0.5 * [ log(s2^2 / s1^2) + (s1^2 + (mu1 - mu2)^2) / s2^2 - 1 ]
  #   = 0.5 * [ (lv2 - lv1) + (exp(lv1) + (mu1 - mu2)^2) / exp(lv2) - 1 ]
  #
  # Summed over the latent dimension, then averaged over the batch.
  kl_elem <- 0.5 * (
    prior_logvar - enc_logvar +
      (torch_exp(enc_logvar) + (enc_mu - prior_mu)^2) / torch_exp(prior_logvar) - 1
  )
  kl_loss <- kl_elem$sum(dim = -1)$mean()   # scalar
  
  # Negative ELBO = -(recon - KL)
  -(recon_loss - kl_loss)
}
