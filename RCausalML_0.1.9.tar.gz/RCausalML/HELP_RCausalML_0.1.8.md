# RCausalML 0.1.8 Tarball Help

This guide explains how to install and use `RCausalML_0.1.8.tar.gz`.

## 1) Install From Tarball

From R:

```r
install.packages("RCausalML_0.1.8.tar.gz", repos = NULL, type = "source")
```

From shell:

```bash
R CMD INSTALL RCausalML_0.1.8.tar.gz
```

## 2) Dependency Setup Behavior

`RCausalML` version `0.1.8` includes an install-time `configure` hook.

- In an **interactive** install, it can prompt you to approve installing/updating dependencies.
- In a **non-interactive** install (CI, scripts, some IDE/background runs), it skips auto-install and prints the manual command to run.

## 3) Manual Dependency Install/Update (Recommended)

If dependencies are missing or old:

```r
install.packages(c(
  "glmnet", "ranger", "rpart", "R6", "expm", "igraph", "progress", "htetree",
  "xgboost", "torch", "grf", "DoubleML", "mlr3", "mlr3learners",
  "mlr3tuning", "paradox", "mlr3measures", "MatchIt", "reticulate",
  "kernelshap", "shapviz", "causaldata"
))
```

Core packages are in `Imports`; others are optional (`Suggests`) and needed for specific models/features.

- **`xgboost`**: required by `CXGBoost` and `MultiArmCausalBoost` (new in 0.1.8).
- **`torch (>= 0.10)`**: required by `TemporalCausalVAE`, `InterventionalCRL`, TCDF (`temporalCausaDiscovery`), CEVAE, DragonNet, and other deep causal nets.

## 4) Load Package

```r
library(RCausalML)
```

If installed to a project-local library (for example `.Rlibrary`), set library paths first:

```r
.libPaths(c("RCausalML/.Rlibrary", .libPaths()))
library(RCausalML)
```

## 5) Quick Smoke Test

```r
library(RCausalML)
set.seed(42)
d <- synthetic_data(mode = 1, n = 400, p = 5, sigma = 1)
m <- SLearner(learner = "ranger")
m <- fit(m, d$X, d$w, d$y)
ate <- estimate_ate(m, d$X, d$w, d$y)
print(ate)
```

## 6) New in 0.1.8 — Quick Tests

### Causal XGBoost (`CXGBoost`)

```r
library(RCausalML)
library(xgboost)
library(ranger)
set.seed(1)
n <- 300; p <- 5
X  <- matrix(rnorm(n * p), n, p)
w  <- rbinom(n, 1, 0.5)
y  <- 2 * w + X[, 1] + rnorm(n)
mod <- CXGBoost$new(nrounds = 50, n_trees = 100)
mod$fit(X, w, y)
tau_hat <- mod$predict(X)
cat("ATE estimate:", mean(tau_hat), "\n")
mod$summary()
```

### Multi-arm Causal Boosting (`MultiArmCausalBoost`)

```r
library(RCausalML)
set.seed(2)
n <- 200; p <- 4
X  <- matrix(rnorm(n * p), n, p)
W  <- factor(sample(c("control","trt1","trt2"), n, replace = TRUE))
y  <- ifelse(W == "trt1", 1, ifelse(W == "trt2", 2, 0)) + rnorm(n)
mod <- MultiArmCausalBoost$new(nrounds = 30)
mod$fit(X, y, W)
preds <- mod$predict(X)
cat("Contrast names:", names(preds$contrasts), "\n")
```

### Temporal Causal VAE (`TemporalCausalVAE`)

```r
if (requireNamespace("torch", quietly = TRUE)) {
  library(torch)
  source("R/tempoCausalVAE.R")
  model <- TemporalCausalVAE(obs_dim = 3L, latent_dim = 3L, hidden_dim = 64L)
  x_seq <- torch_randn(8L, 10L, 3L)
  out   <- model(x_seq)
  cat("Latent shape:", paste(out$z$shape, collapse = "x"), "\n")
}
```

## 7) Common Issues

- **Permission denied to default R library**
  - Install to a writable local library:
    ```bash
    mkdir -p .Rlibrary
    R CMD INSTALL -l .Rlibrary RCausalML_0.1.8.tar.gz
    ```

- **Repository/index access errors**
  - Check internet access and CRAN mirror:
    ```r
    options(repos = c(CRAN = "https://cloud.r-project.org"))
    ```
  - Then run `install.packages(...)` again.

- **Torch/CUDA warnings**
  - CPU execution is expected when CUDA is unavailable.
  - Most algorithms still run on CPU.

- **`xgboost` not found when using `CXGBoost` or `MultiArmCausalBoost`**
  - Install with `install.packages("xgboost")`.

## 8) Where To Look Next

- Main package documentation: `README.md`
- Change log: `NEWS.md`
- Function help in R: `?SLearner`, `?DMLearner`, `?causalStructureML`, `?CXGBoost`
- Test scripts for examples: `tests/`
