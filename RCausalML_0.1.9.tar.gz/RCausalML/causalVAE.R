# ==============================================================================
#  causalVAE.R
# Causal Variational Autoencoder (CausalVAE) — R/torch implementation
# NUMERICAL STABILITY FIXES - VERSION 2
# ==============================================================================
  
# ==============================================================================
# 1. LIBRARIES AND DEVICE (optional: only run if torch available so package loads)
# ==============================================================================
# torch is in Suggests; avoid failing package load when torch is not installed.
if (requireNamespace("torch", quietly = TRUE)) {
  suppressPackageStartupMessages(library(torch))
  if (requireNamespace("progress", quietly = TRUE))
    suppressPackageStartupMessages(library(progress))
  device <- if (torch::cuda_is_available()) "cuda" else "cpu"
  cat(sprintf("Using device: %s\n", device))
  set.seed(42)
  torch::torch_manual_seed(42L)
} else {
  device <- "cpu"
}

# ==============================================================================
# 3. DATA GENERATION
# ==============================================================================
generate_data <- function(n_samples = 5000L, latent_dim = 3L) {
  epsilon_mat <- matrix(rnorm(n_samples * latent_dim), 
                        nrow = n_samples, ncol = latent_dim)
  z_mat <- matrix(0.0, nrow = n_samples, ncol = latent_dim)
  x_mat <- matrix(0.0, nrow = n_samples, ncol = latent_dim)
  
  z_mat[, 1] <- epsilon_mat[, 1]
  z_mat[, 2] <- z_mat[, 1] + epsilon_mat[, 2]
  z_mat[, 3] <- z_mat[, 2]^2 + epsilon_mat[, 3]
  
  x_mat[, 1] <- z_mat[, 1] * z_mat[, 3]
  x_mat[, 2] <- sin(z_mat[, 2]) + z_mat[, 1]
  x_mat[, 3] <- z_mat[, 3]^2 + rnorm(n_samples, 0, 0.1)
  
  list(
    x = torch_tensor(x_mat, dtype = torch_float(), device = device),
    z = torch_tensor(z_mat, dtype = torch_float(), device = device),
    epsilon = torch_tensor(epsilon_mat, dtype = torch_float(), device = device)
  )
}

# ==============================================================================
# 4. CausalVAE MODEL — WITH NUMERICAL STABILITY
# ==============================================================================
CausalVAE <- nn_module(
  classname = "CausalVAE",
  
  initialize = function(
    input_dim = 3L,
    latent_dim = 3L,
    hidden_dim = 64L,
    beta = 1.0,            # FIX: Standard VAE beta
    gamma = 0.01,          # FIX: Much smaller gamma for stability
    lambda_sparsity = 0.001, # FIX: Much smaller sparsity
    alpha = 0.001          # FIX: Smaller alpha for DAG penalty
  ) {
    self$beta <- beta
    self$gamma <- gamma
    self$lambda_sparsity <- lambda_sparsity
    self$alpha <- alpha
    self$latent_dim <- as.integer(latent_dim)
    
    self$enc_fc1 <- nn_linear(input_dim, hidden_dim)
    self$enc_fc2 <- nn_linear(hidden_dim, hidden_dim)
    self$enc_mu <- nn_linear(hidden_dim, latent_dim)
    self$enc_logvar <- nn_linear(hidden_dim, latent_dim)
    
    self$dec_fc1 <- nn_linear(latent_dim, hidden_dim)
    self$dec_fc2 <- nn_linear(hidden_dim, hidden_dim)
    self$dec_mu <- nn_linear(hidden_dim, input_dim)
    self$dec_logvar <- nn_linear(hidden_dim, input_dim)
    
    self$a_weights <- nn_parameter(torch_randn(latent_dim, latent_dim) * 0.01)
    self$m_logits <- nn_parameter(torch_randn(latent_dim, latent_dim) * 0.01)
  },
  
  encode = function(x) {
    h <- torch_relu(self$enc_fc1(x))
    h <- torch_relu(self$enc_fc2(h))
    mu <- self$enc_mu(h)
    # FIX: Clamp logvar to prevent numerical explosion
    logvar <- torch_clamp(self$enc_logvar(h), min = -5, max = 5)
    list(mu = mu, logvar = logvar)
  },
  
  reparameterize = function(mu, logvar) {
    std <- torch_exp(0.5 * logvar)
    eta <- torch_randn_like(std)
    mu + eta * std
  },
  
  causal_layer = function(epsilon) {
    A <- torch_tanh(self$a_weights)
    M <- torch_sigmoid(self$m_logits)
    AM <- A * M
    # Use approximation (more stable than matrix inverse)
    epsilon + torch_matmul(AM, epsilon$unsqueeze(-1L))$squeeze(-1L)
  },
  
  decode = function(z) {
    h <- torch_relu(self$dec_fc1(z))
    h <- torch_relu(self$dec_fc2(h))
    mu <- self$dec_mu(h)
    # FIX: Clamp decoder logvar
    logvar <- torch_clamp(self$dec_logvar(h), min = -5, max = 5)
    list(mu = mu, logvar = logvar)
  },
  
  dag_penalty = function() {
    M <- torch_sigmoid(self$m_logits)
    eye <- torch_eye(self$latent_dim, device = M$device)
    Mat <- eye + self$alpha * M * M
    dag_val <- torch_trace(torch_matrix_exp(Mat)) - self$latent_dim
    # FIX: Ensure non-negative DAG penalty
    torch_relu(dag_val)
  },
  
  forward = function(x) {
    enc_out <- self$encode(x)
    epsilon <- self$reparameterize(enc_out$mu, enc_out$logvar)
    z <- self$causal_layer(epsilon)
    dec_out <- self$decode(z)
    list(
      enc_mu = enc_out$mu,
      enc_logvar = enc_out$logvar,
      dec_mu = dec_out$mu,
      dec_logvar = dec_out$logvar,
      z = z,
      epsilon = epsilon
    )
  }
)

# ==============================================================================
# 5. CausalVAE_ATE
# ==============================================================================
CausalVAE_ATE <- nn_module(
  classname = "CausalVAE_ATE",
  inherit = CausalVAE,
  
  initialize = function(...) {
    super$initialize(...)
    self$y_pred <- nn_linear(self$latent_dim + 1L, 1L)
  },
  
  forward = function(x, T = NULL) {
    out <- super$forward(x)
    if (!is.null(T)) {
      out$y_pred <- self$y_pred(torch_cat(list(out$z, T), dim = 2L))
    }
    out
  }
)

# ==============================================================================
# 6. estimate_ate.CausalVAE_ATE() — S3 method for ATE from CausalVAE_ATE model
# ==============================================================================
#' @export
estimate_ate.CausalVAE_ATE <- function(obj, ..., n_samples = 500L, treatment_dim = 1L, shift = 1.0) {
  model <- obj
  model$eval()
  with_no_grad({
    epsilon <- torch_randn(n_samples, model$latent_dim)$to(device = device)
    
    z_t0 <- model$causal_layer(epsilon)
    T0 <- torch_zeros(n_samples, 1L)$to(device = device)
    y_t0 <- model$y_pred(torch_cat(list(z_t0, T0), dim = 2L))$mean()
    
    z_t1 <- model$causal_layer(epsilon)
    delta <- torch_zeros_like(z_t1)
    delta[, treatment_dim] <- shift
    z_t1 <- z_t1 + delta
    
    T1 <- torch_ones(n_samples, 1L)$to(device = device)
    y_t1 <- model$y_pred(torch_cat(list(z_t1, T1), dim = 2L))$mean()
    
    (y_t1 - y_t0)$item()
  })
}

# ==============================================================================
# 7. LOSS FUNCTION 
# ==============================================================================
loss_function <- function(x, dec_mu, dec_logvar, enc_mu, enc_logvar, 
                          model, gamma_scale = 1.0) {
  # FIX: Positive reconstruction loss (minimize)
  recon_loss <- torch_mean(0.5 * torch_sum((x - dec_mu)^2, dim = -1L))
  
  # FIX: Clamp logvar for stability
  enc_logvar <- torch_clamp(enc_logvar, min = -10, max = 10)
  
  # KL divergence
  kl_loss <- torch_mean(0.5 * torch_sum(
    torch_exp(enc_logvar) + enc_mu^2 - 1 - enc_logvar,
    dim = -1L
  ))
  
  # DAG penalty with clamping
  dag_loss <- torch_clamp(model$dag_penalty(), min = 0, max = 100)
  
  # Sparsity
  sparsity_loss <- torch_sum(torch_abs(torch_sigmoid(model$m_logits)))
  
  # Total loss (all POSITIVE terms to minimize)
  recon_loss + model$beta * kl_loss + 
    gamma_scale * model$gamma * (dag_loss + model$lambda_sparsity * sparsity_loss)
}

# ==============================================================================
# 8. TRAINING LOOP — WITH LOSS VALIDATION
# ==============================================================================
train_causalvae <- function(
    model,
    train_loader,
    val_loader,
    epochs = 200L,
    warmup_epochs = 40L,
    batch_size = 256L,
    val_frequency = 10L,
    patience = 30L,
    min_delta = 1e-4
) {
  # FIX: Lower learning rate for stability
  optimizer <- optim_adam(model$parameters, lr = 1e-4, weight_decay = 1e-5)
  scheduler <- lr_reduce_on_plateau(optimizer, mode = "min", factor = 0.5, patience = 15)
  
  train_losses <- numeric(epochs)
  val_losses <- numeric(epochs)
  
  best_val_loss <- Inf
  no_improve_count <- 0
  
  pb <- progress_bar$new(
    total = epochs,
    format = "[:bar] :percent Epoch :current/:total ETA: :eta",
    clear = FALSE
  )
  
  for (epoch in 1:epochs) {
    gamma_scale <- min(1.0, (epoch + 1) / warmup_epochs)
    
    model$train()
    epoch_loss <- 0
    n_batches <- 0
    
    if (!requireNamespace("coro", quietly = TRUE))
      stop("package 'coro' is required; install with install.packages('coro')")
    train_batches <- coro::collect(train_loader)
    
    for (batch in train_batches) {
      x_batch <- batch[[1]]$to(device = device)
      
      optimizer$zero_grad()
      out <- model$forward(x_batch)
      
      loss <- loss_function(
        x_batch, out$dec_mu, out$dec_logvar,
        out$enc_mu, out$enc_logvar, model, gamma_scale
      )
      
      # FIX: Check for NaN/Inf BEFORE backward
      loss_val <- loss$item()
      if (!is.finite(loss_val) || loss_val > 1e6) {
        cat(sprintf("\nWarning: Loss is %s at epoch %d, skipping batch\n", 
                    ifelse(is.nan(loss_val), "NaN", "Inf"), epoch))
        next
      }
      
      loss$backward()
      tryCatch(
        nn_utils_clip_grad_norm_(model$parameters, max_norm = 1.0),
        error = function(e) NULL
      )
      optimizer$step()
      
      epoch_loss <- epoch_loss + loss_val
      n_batches <- n_batches + 1
    }
    
    train_losses[epoch] <- if (n_batches > 0) epoch_loss / n_batches else Inf
    
    if (epoch %% val_frequency == 0 || epoch == epochs) {
      model$eval()
      val_loss <- 0
      n_val_batches <- 0
      
      val_batches <- coro::collect(val_loader)
      with_no_grad({
        for (batch in val_batches) {
          x_batch <- batch[[1]]$to(device = device)
          out <- model$forward(x_batch)
          loss <- loss_function(
            x_batch, out$dec_mu, out$dec_logvar,
            out$enc_mu, out$enc_logvar, model, gamma_scale
          )
          loss_val <- loss$item()
          if (is.finite(loss_val)) {
            val_loss <- val_loss + loss_val
            n_val_batches <- n_val_batches + 1
          }
        }
      })
      
      val_loss_avg <- if (n_val_batches > 0) val_loss / n_val_batches else Inf
      
      # FIX: Handle invalid validation loss
      if (!is.finite(val_loss_avg)) {
        cat(sprintf("\nWarning: Validation loss is %s at epoch %d\n",
                    ifelse(is.nan(val_loss_avg), "NaN", "Inf"), epoch))
        val_loss_avg <- best_val_loss
      }
      
      val_losses[epoch] <- val_loss_avg
      
      if (is.finite(val_loss_avg)) {
        scheduler$step(val_loss_avg)
      }
      
      if (val_loss_avg < best_val_loss - min_delta) {
        best_val_loss <- val_loss_avg
        no_improve_count <- 0
      } else {
        no_improve_count <- no_improve_count + 1
      }
      
      if (no_improve_count >= patience) {
        cat(sprintf("\nEarly stopping at epoch %d\n", epoch))
        train_losses <- train_losses[1:epoch]
        val_losses <- val_losses[1:epoch]
        break
      }
    }
    
    pb$tick()
    
    if (epoch %% 50 == 0) {
      cat(sprintf("\nEpoch %d, Train: %.4f, Val: %.4f\n",
                  epoch, train_losses[epoch],
                  ifelse(epoch %% val_frequency == 0, val_losses[epoch], NA)))
    }
  }
  
  list(
    train_losses = train_losses,
    val_losses = val_losses,
    best_val_loss = best_val_loss
  )
}

# ==============================================================================
# 9. HYPERPARAMETER TUNING
# ==============================================================================
tune_hyperparameters <- function(
    train_loader, val_loader,
    n_trials = 10L,
    n_epochs_per_trial = 50L
) {
  best_loss <- Inf
  best_params <- list()
  
  for (trial in 1:n_trials) {
    lr <- 10^runif(1, -5, -3)
    beta <- runif(1, 0.5, 2.0)
    gamma <- runif(1, 0.001, 0.01)
    hidden_dim <- sample(c(32L, 64L), 1)
    
    model <- CausalVAE(
      input_dim = 3L,
      latent_dim = 3L,
      hidden_dim = hidden_dim,
      beta = beta,
      gamma = gamma
    )$to(device = device)
    
    optimizer <- optim_adam(model$parameters, lr = lr, weight_decay = 1e-5)
    
    val_loss <- Inf
    for (epoch in 1:n_epochs_per_trial) {
      gamma_scale <- min(1.0, epoch / 20)
      model$train()
      
      train_batches <- coro::collect(train_loader)
      for (batch in train_batches) {
        x_batch <- batch[[1]]$to(device = device)
        optimizer$zero_grad()
        out <- model$forward(x_batch)
        loss <- loss_function(x_batch, out$dec_mu, out$dec_logvar,
                              out$enc_mu, out$enc_logvar, model, gamma_scale)
        
        if (is.finite(loss$item())) {
          loss$backward()
          optimizer$step()
        }
      }
      
      if (epoch %% 10 == 0) {
        model$eval()
        with_no_grad({
          vl <- 0
          nb <- 0
          val_batches <- coro::collect(val_loader)
          for (batch in val_batches) {
            x_batch <- batch[[1]]$to(device = device)
            out <- model$forward(x_batch)
            loss_val <- loss_function(x_batch, out$dec_mu, out$dec_logvar,
                                      out$enc_mu, out$enc_logvar, model, gamma_scale)$item()
            if (is.finite(loss_val)) {
              vl <- vl + loss_val
              nb <- nb + 1
            }
          }
          if (nb > 0) val_loss <- vl / nb
        })
      }
    }
    
    cat(sprintf("Trial %d: val_loss = %.4f\n", trial, val_loss))
    
    if (val_loss < best_loss && is.finite(val_loss)) {
      best_loss <- val_loss
      best_params <- list(lr = lr, beta = beta, gamma = gamma, hidden_dim = hidden_dim)
    }
  }
  
  best_params
}

# ==============================================================================
# 10. PERFORMANCE SUMMARY
# ==============================================================================
print_optimization_summary <- function() {
  cat("\n========================================\n")
  cat("NUMERICAL STABILITY FIXES v2\n")
  cat("========================================\n")
  cat("  • Loss clamping: REMOVED\n")
  cat("  • Loss signs: All POSITIVE (minimize)\n")
  cat("  • Learning rate: 1e-4 (more stable)\n")
  cat("  • Gamma: 0.01 (smaller causal penalty)\n")
  cat("  • Logvar clamp: [-5, 5]\n")
  cat("  • DAG penalty: ReLU (non-negative)\n")
  cat("  • Loss validation: Before backward()\n")
  cat("========================================\n")
}